package fag;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import fag.objeto.Vendas;


public class Calculadora {
	public static Scanner scan = new Scanner(System.in);
	static double precoTotal=0;
	
	
	private static List<Vendas> venda = new ArrayList<>();
	
	
	public static void main(String[] args) {
		
		mostrarMenu();
		
	}

	private static void mostrarMenu() {
		int escolha = 0;
		
		System.out.println("------BEM VINDO------");
		do {
			System.out.println("\n----- MENU -----\n");
			System.out.println("1 - Calcular preco total");
			System.out.println("2 - Calcular troco");
			System.out.println("3 - Listar vendas");
			System.out.println("4 - Sair");
			System.out.println("\nDigite sua escolha: ");
			escolha = scan.nextInt(); 
			scan.nextLine();
			
			validarEscolha(escolha);
			
		}while(escolha!= 3);
		
		
	}

	public static void validarEscolha(int escolha) {
		switch (escolha) {
		case 1:
			calcularPreco();
			break;
		case 2:
			calcularTroco(precoTotal);
			break;
		case 3:
			//listarVendas();
			break;
		case 4:
			System.out.println("\nEncerrando...");
			System.out.println("\nOperacao concluida!");
			break;
		default:
			System.out.println("\nSelecione uma opcao valida!!!");
			break;
		
		}
		
	}

	public static void calcularPreco() {
		Vendas vendas = new Vendas();
		
		System.out.println("\nInsira a quantidade de plantas que deseja comprar: ");
		vendas.setQuantidade(scan.nextInt());
		//int quantidade = scan.nextInt();
		scan.nextLine();
		
		System.out.println("\nInsira o valor unitario da planta: ");
		vendas.setValorUnitario(scan.nextInt());
		
		//double valor = scan.nextDouble();
		
		precoTotal = (vendas.getValorUnitario() * vendas.getQuantidade());
		
		if(vendas.getQuantidade() > 10) {
			precoTotal = (precoTotal -(precoTotal * 5/100));
			System.out.println("\nO valor total da compra com desconto de 5 por cento1 e R$: " + precoTotal);
		}
		else {
			System.out.println("\nO valor total da compra e R$: " + precoTotal);
		}
		
		
		venda.add(vendas);
		
		//calcularTroco(precoTotal);
	}

	public static void calcularTroco(double precoTotal) {
		
		if(precoTotal == 0) {
			System.out.println("\nCalcule o total antes!");
			return;	
		}
		
		System.out.println("\nDigite o valor do pagamento: ");
		double pagamento = scan.nextDouble();
		
		if(pagamento < precoTotal) {
			System.out.println("\nValor de pagamento insuficiente!!!");
			return;
		}else if(pagamento == precoTotal){
			System.out.println("\nObrigado, pagamento de acordo!");
		}else {
			double troco = pagamento - precoTotal;
			System.out.printf("\nSeu troco e R$: %.2f", troco);
		}

	
	}

}
