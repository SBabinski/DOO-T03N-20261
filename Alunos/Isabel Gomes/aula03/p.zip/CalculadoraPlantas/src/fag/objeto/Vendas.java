package fag.objeto;

public class Vendas {
	
	
	private int quantidade;
	private double valorFinal;
	private int valorUnitario;
	private int desconto=5;
	
	
	public int getQuantidade() {
		return quantidade;
	}
	
	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}
	
	
	public double valorFinal() {
		return valorFinal;
	}
	
	public void setValorFinal(double valorFinal) {
		this.valorFinal = valorFinal;
	}
	
	
	

	public int getValorUnitario() {
		return valorUnitario;
	}

	public void setValorUnitario(int valorUnitario) {
		this.valorUnitario = valorUnitario;
	}
	
	public int getDesconto() {
		return desconto;
	}
	
	//criar metodos descontos bool
	
	
	//metodo imprimir a listagem d evendas
	
	
	

}
